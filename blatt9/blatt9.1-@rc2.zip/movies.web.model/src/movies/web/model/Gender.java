package movies.web.model;

public enum Gender {
	Male, Female;
}
