package movies.web.model;

public enum Rating {
	Zero, One, Two, Three, Four, Five;
}
