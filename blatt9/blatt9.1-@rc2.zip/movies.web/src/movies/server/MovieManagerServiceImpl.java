package movies.server;

import movies.client.service.MovieManagerService;
import movies.emfstore.client.EMFStoreClient;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class MovieManagerServiceImpl extends RemoteServiceServlet implements
		MovieManagerService {

	private static final long serialVersionUID = -5459930379153769747L;

	private EMFStoreClient client = new EMFStoreClient();

}
