package movies.client.service;

public interface MovieManagerServiceAsync {

}
