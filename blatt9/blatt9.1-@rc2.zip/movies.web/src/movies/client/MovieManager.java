package movies.client;

import movies.client.service.MovieManagerService;
import movies.client.service.MovieManagerServiceAsync;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.shared.GWT;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class MovieManager implements EntryPoint {

	/**
	 * The service to talk to.
	 * */
	private MovieManagerServiceAsync movieService = GWT
			.create(MovieManagerService.class);

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
	}

}
