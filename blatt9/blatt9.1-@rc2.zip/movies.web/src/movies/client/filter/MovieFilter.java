package movies.client.filter;

import movies.web.model.Movie;

/**
 * A filter for {@link Movie}. The filter is valid if the name of a movie
 * contains the filter text.
 * */
public class MovieFilter implements IFilter<Movie> {

	@Override
	public boolean isValid(Movie value, String filter) {
		return value.getTitle().toLowerCase().contains(filter.toLowerCase());
	}

}
