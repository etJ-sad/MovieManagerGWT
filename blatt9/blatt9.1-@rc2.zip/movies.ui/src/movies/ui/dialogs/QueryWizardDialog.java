package movies.ui.dialogs;

import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Shell;

public class QueryWizardDialog extends WizardDialog {

	public QueryWizardDialog(Shell parentShell, IWizard newWizard) {

		super(parentShell, newWizard);
	}
	

}
