/** Soloninov Aleksandr, ISW WS 15|16
 * Blatt 1, Aufgabe 1.3
 * Relase 1.0.0
 */

public enum Gender {
    MALE, FEMALE
}