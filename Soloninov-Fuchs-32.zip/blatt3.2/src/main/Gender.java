package main;

/**  Gender Class.
 * @version 1.2.1
 */
/** @version 1.0.1:relase
 */
public enum Gender {

    /** The male. */
    MALE,
 /** The female. */
 FEMALE
}
