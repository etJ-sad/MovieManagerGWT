/**
  *
  * Package-info, Soloninov Aleksandr | ISW 15/16.
  * @version 2.0.1:relase
  */
package main;
