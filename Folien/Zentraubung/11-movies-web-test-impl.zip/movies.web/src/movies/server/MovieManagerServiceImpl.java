package movies.server;

import java.util.ArrayList;
import java.util.List;

import movies.client.service.MovieManagerService;
import movies.emfstore.client.EMFStoreClient;
import movies.emfstore.client.EMFStoreClientException;
import movies.web.model.Movie;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class MovieManagerServiceImpl extends RemoteServiceServlet implements
		MovieManagerService {

	private static final long serialVersionUID = -5459930379153769747L;

	private EMFStoreClient client = new EMFStoreClient();

	@Override
	public List<Movie> listLoanableMovies() {
		List<Movie> loanableMovies = new ArrayList<Movie>();

		for (Movie movie : client.getMovies()) {
			if (movie.isLoanable() && !movie.isLoaned()) {
				loanableMovies.add(movie);
			}
		}

		return loanableMovies;
	}

	@Override
	public List<Movie> listLoanedMovies() {
		List<Movie> loanedMovies = new ArrayList<Movie>();

		for (Movie movie : client.getMovies()) {
			if (movie.isLoaned()) {
				loanedMovies.add(movie);
			}
		}

		return loanedMovies;
	}

	@Override
	public void loanMovie(Movie movie) {
		try {
			client.loanMovie(movie);
		} catch (EMFStoreClientException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void returnMovie(Movie movie) {
		try {
			client.returnMovie(movie);
		} catch (EMFStoreClientException e) {
			e.printStackTrace();
		}
	}

}
