package movies.client.ui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Dialog to show an error message.
 * */
public class ErrorMessageDialog extends DialogBox {

	// Creates a error dialog box with the given error message.
	public ErrorMessageDialog(String errorMessage) {
		// Sets the caption of the dialog
		setText("Error");

		// Used for styling (optional)
		setGlassEnabled(true);
		setAnimationEnabled(true);

		VerticalPanel panel = new VerticalPanel();

		panel.add(new Label(errorMessage));

		Button closeButton = new Button("Close");
		closeButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				ErrorMessageDialog.this.hide();
			}
		});

		panel.add(closeButton);

		setWidget(panel);
	}

}
