package movies.client.ui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import movies.client.filter.FilteredListDataProvider;
import movies.client.filter.MovieFilter;
import movies.client.service.MovieManagerService;
import movies.client.service.MovieManagerServiceAsync;
import movies.web.model.Loanable;
import movies.web.model.Movie;

import com.google.gwt.cell.client.TextCell;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.CalendarUtil;
import com.google.gwt.user.datepicker.client.DatePicker;
import com.google.gwt.view.client.SingleSelectionModel;

/**
 * View to show all loanable movies and to loan movies.
 * */
public class LoanablesView extends Composite {

	// The movie manager service
	private final MovieManagerServiceAsync movieService = GWT
			.create(MovieManagerService.class);

	// Table to display loanable movies
	private CellTable<Movie> loanableMoviesTable;

	// Data provider for loanable movies
	private FilteredListDataProvider<Movie> loanableMovieProvider;

	// Main panel to add our widgets to
	private VerticalPanel loanablePanel;

	// List to store our movies
	private List<Movie> loanableMoviesList;

	// Model to select a single movie from a table
	private SingleSelectionModel<Loanable> selection;

	// Creates a new loanable view
	public LoanablesView(List<Movie> movies) {
		clear();
		loanableMoviesList = new ArrayList<Movie>(movies);
	}

	// Adds all the content to main panel
	public void initialize() {
		loanablePanel = new VerticalPanel();
		loanablePanel.setSpacing(15);

		HorizontalPanel loanesOrLoanablesPanel = new HorizontalPanel();
		loanesOrLoanablesPanel.setSpacing(5);
		loanesOrLoanablesPanel
				.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		loanesOrLoanablesPanel
				.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		loanesOrLoanablesPanel.add(new HTML("<h2>View and Loan Items or</h2>"));

		// The anchor is used to navigate to the loaned view.
		Anchor loansViewLink = new Anchor(" View Loans");
		loansViewLink.setHTML("<h2>View Loans</h2>");
		loansViewLink.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				// Get all loaned movies and show loaned view
				movieService.listLoanedMovies(new AsyncCallback<List<Movie>>() {

					@Override
					public void onSuccess(List<Movie> result) {
						LoansView loansView = new LoansView(result);
						loansView.initialize();
						loansView.show();
					}

					@Override
					public void onFailure(Throwable caught) {
						GWT.log(caught.getMessage());
					}
				});
			}
		});

		loanesOrLoanablesPanel.add(loansViewLink);
		loanablePanel.add(loanesOrLoanablesPanel);

		selection = new SingleSelectionModel<Loanable>();

		HorizontalPanel filterAndLoanPanel = new HorizontalPanel();
		filterAndLoanPanel.setSpacing(10);
		filterAndLoanPanel
				.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		filterAndLoanPanel
				.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		filterAndLoanPanel.add(new Label("Filter:"));

		final TextBox filterTextBox = new TextBox();
		filterTextBox.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> event) {
				loanableMovieProvider.setFilter(filterTextBox.getText());
			}
		});

		Button loanButton = new Button("Loan");
		loanButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				Movie loan = null;
				for (Movie movie : loanableMoviesList) {
					if (selection.isSelected(movie)) {
						loan = movie;
						break;
					}
				}

				if (loan != null) {
					new LoanDateDialog(loan).center();
				} else {
					new ErrorMessageDialog(
							"You have to select a movie to loan!").center();
				}
			}
		});

		filterAndLoanPanel.add(filterTextBox);
		filterAndLoanPanel.add(loanButton);

		loanablePanel.add(filterAndLoanPanel);

		createLoanedMovieTable();

		initWidget(loanablePanel);
		RootPanel.get("content").add(this);
	}

	// Updates the table on changes
	private void updateTables() {
		loanableMovieProvider.setList(loanableMoviesList);
	}

	// Creates the loanable movie table
	private void createLoanedMovieTable() {
		loanablePanel.add(new HTML("<h3>Loanable Movies</h3>"));
		loanableMoviesTable = new CellTable<Movie>();

		loanableMovieProvider = new FilteredListDataProvider<>(
				new MovieFilter());
		loanableMovieProvider.addDataDisplay(loanableMoviesTable);
		loanableMovieProvider.setList(loanableMoviesList);
		loanableMoviesTable.setSelectionModel(selection);

		Column<Movie, String> titleColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return object.getTitle();
			}
		};

		Column<Movie, String> timeColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return "" + object.getTime();
			}
		};

		Column<Movie, String> categoryColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return object.getCategory().name();
			}
		};

		Column<Movie, String> ratingColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return "" + object.getRating().ordinal();
			}
		};

		loanableMoviesTable.addColumn(titleColumn, "Title");
		loanableMoviesTable.addColumn(timeColumn, "Time");
		loanableMoviesTable.addColumn(categoryColumn, "Category");
		loanableMoviesTable.addColumn(ratingColumn, "Rating");

		titleColumn.setSortable(true);
		timeColumn.setSortable(true);
		categoryColumn.setSortable(true);
		ratingColumn.setSortable(true);

		ListHandler<Movie> sortHandler = new ListHandler<Movie>(
				loanableMovieProvider.getList());
		loanableMoviesTable.addColumnSortHandler(sortHandler);

		sortHandler.setComparator(titleColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				return o1.getTitle().compareTo(o2.getTitle());
			}
		});

		sortHandler.setComparator(timeColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				if (o1.getTime() > o2.getTime()) {
					return 1;
				}
				if (o1.getTime() < o2.getTime()) {
					return -1;
				}
				return 0;
			}
		});

		sortHandler.setComparator(categoryColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				return o1.getCategory().name()
						.compareTo(o2.getCategory().name());
			}
		});

		sortHandler.setComparator(ratingColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				if (o1.getRating().ordinal() > o2.getRating().ordinal()) {
					return 1;
				}
				if (o1.getRating().ordinal() < o2.getRating().ordinal()) {
					return -1;
				}
				return 0;
			}
		});

		loanablePanel.add(loanableMoviesTable);
	}

	// Show this page
	public void show() {
		setVisible(true);
	}

	// Removes existing widgets from the web-page.
	private void clear() {
		RootPanel.get("content").clear();
	}

	// Dialog to select the return date
	private class LoanDateDialog extends DialogBox {

		// Callback to loan movies.
		private class LoanCallback implements AsyncCallback<Void> {

			private Movie toLoan;

			public LoanCallback(Movie movieToLoan) {
				toLoan = movieToLoan;
			}

			@Override
			public void onFailure(Throwable caught) {
				GWT.log(caught.getMessage());
			}

			@Override
			public void onSuccess(Void result) {
				loanableMoviesList.remove(toLoan);
				updateTables();
			}

		}

		private Date loanedUntil;

		public LoanDateDialog(final Movie movieToLoan) {
			// Set the dialog box's caption.
			setText("Loan the movie until");

			// Enable animation.
			setAnimationEnabled(true);

			// Enable glass background.
			setGlassEnabled(true);

			VerticalPanel panel = new VerticalPanel();
			panel.setSpacing(10);

			HorizontalPanel hp = new HorizontalPanel();
			hp.setSpacing(50);

			DatePicker picker = new DatePicker();
			picker.addValueChangeHandler(new ValueChangeHandler<Date>() {

				@Override
				public void onValueChange(ValueChangeEvent<Date> event) {
					loanedUntil = event.getValue();
				}
			});

			panel.add(picker);

			Button loanButton = new Button("Loan");
			loanButton.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {

					if (isBeforeTommorow(loanedUntil)) {
						new ErrorMessageDialog(
								"The return date must be later than today's date!")
								.center();
						return;
					}
					if (isLoanPeriodExceeded(loanedUntil)) {
						new ErrorMessageDialog(
								"The return date cannot be later than today's date + 14 days!")
								.center();
						return;
					}
					LoanDateDialog.this.hide();
					movieToLoan.setLoanedUntil(loanedUntil);
					movieService.loanMovie(movieToLoan, new LoanCallback(
							movieToLoan));
				}

				private boolean isLoanPeriodExceeded(Date loanedUntil) {
					Date returnDate = new Date();
					CalendarUtil.addDaysToDate(returnDate, 14);
					return loanedUntil.after(returnDate);
				}

				private boolean isBeforeTommorow(Date loanedUntil) {
					return loanedUntil.before(new Date());
				}

			});

			Button cancelButton = new Button("Cancel");
			cancelButton.addClickHandler(new ClickHandler() {

				@Override
				public void onClick(ClickEvent event) {
					LoanDateDialog.this.hide();
				}
			});

			hp.add(loanButton);
			hp.add(cancelButton);

			panel.add(hp);

			setWidget(panel);
		}
	}

}
