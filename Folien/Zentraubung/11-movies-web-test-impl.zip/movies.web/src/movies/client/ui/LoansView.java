package movies.client.ui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import movies.client.filter.FilteredListDataProvider;
import movies.client.filter.MovieFilter;
import movies.client.service.MovieManagerService;
import movies.client.service.MovieManagerServiceAsync;
import movies.web.model.Movie;

import com.google.gwt.cell.client.TextCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.SingleSelectionModel;

/**
 * View to show all loaned movies and to return loaned movies.
 * */
public class LoansView extends Composite {

	// The movie manager service
	private final MovieManagerServiceAsync movieService = GWT
			.create(MovieManagerService.class);

	// Table to display loaned movies
	private CellTable<Movie> loanedMoviesTable;

	// Data provider for loaned movies
	private FilteredListDataProvider<Movie> loanedMovieProvider;

	// Main panel to add our widgets to
	private VerticalPanel loansPanel;

	// List to store our movies
	private List<Movie> loanedMoviesList;

	// Model to select a single movie from a table
	private SingleSelectionModel<Movie> selection;

	// Creates a new loans view
	public LoansView(List<Movie> movies) {
		clear();
		loanedMoviesList = new ArrayList<Movie>(movies);
	}

	// Adds all the content to main panel
	public void initialize() {
		loansPanel = new VerticalPanel();
		loansPanel.setSpacing(15);

		HorizontalPanel loanesOrLoanablesPanel = new HorizontalPanel();
		loanesOrLoanablesPanel.setSpacing(5);
		loanesOrLoanablesPanel
				.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		loanesOrLoanablesPanel
				.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		loanesOrLoanablesPanel
				.add(new HTML("<h2>View and Return Loans or</h2>"));

		// The anchor is used to navigate to the loanables view.
		Anchor loanablesViewLink = new Anchor(" View Loanables");
		loanablesViewLink.setHTML("<h2>View Loanables</h2>");
		loanablesViewLink.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				// Get all loanable movies and show loanables view
				movieService
						.listLoanableMovies(new AsyncCallback<List<Movie>>() {

							@Override
							public void onFailure(Throwable caught) {
								GWT.log(caught.getMessage());
							}

							@Override
							public void onSuccess(List<Movie> result) {
								LoanablesView view = new LoanablesView(result);
								view.initialize();
								view.show();
							}
						});
			}
		});

		loanesOrLoanablesPanel.add(loanablesViewLink);
		loansPanel.add(loanesOrLoanablesPanel);

		selection = new SingleSelectionModel<Movie>();

		HorizontalPanel filterAndReturnPanel = new HorizontalPanel();
		filterAndReturnPanel.setSpacing(10);
		filterAndReturnPanel
				.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		filterAndReturnPanel
				.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);

		filterAndReturnPanel.add(new Label("Filter:"));

		final TextBox filterTextBox = new TextBox();
		filterTextBox.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> event) {
				loanedMovieProvider.setFilter(filterTextBox.getText());
			}
		});

		Button returnLoanButton = new Button("Return");
		returnLoanButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				Movie toReturn = null;
				for (Movie movie : loanedMoviesList) {
					if (selection.isSelected(movie)) {
						toReturn = movie;
					}
				}

				if (toReturn != null) {
					movieService.returnMovie(toReturn, new ReturnLoanCallback(
							toReturn));
				} else {
					new ErrorMessageDialog(
							"You have to select a movie to return!").center();
				}
			}
		});

		filterAndReturnPanel.add(filterTextBox);
		filterAndReturnPanel.add(returnLoanButton);

		loansPanel.add(filterAndReturnPanel);

		createLoanedMovieTable();

		initWidget(loansPanel);
		RootPanel.get("content").add(this);
	}

	// Updates the table on changes
	private void updateTables() {
		loanedMovieProvider.setList(loanedMoviesList);
	}

	// Creates the loaned movie table
	private void createLoanedMovieTable() {
		loansPanel.add(new HTML("<h3>Loaned Movies:</h3>"));
		loanedMoviesTable = new CellTable<Movie>();

		loanedMovieProvider = new FilteredListDataProvider<>(new MovieFilter());
		loanedMovieProvider.addDataDisplay(loanedMoviesTable);
		loanedMovieProvider.setList(loanedMoviesList);
		loanedMoviesTable.setSelectionModel(selection);

		Column<Movie, String> titleColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return object.getTitle();
			}
		};

		Column<Movie, String> timeColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return "" + object.getTime();
			}
		};

		Column<Movie, String> categoryColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return object.getCategory().name();
			}
		};

		Column<Movie, String> ratingColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				return "" + object.getRating().ordinal();
			}
		};

		Column<Movie, String> loanedUntilColumn = new Column<Movie, String>(
				new TextCell()) {

			@Override
			public String getValue(Movie object) {
				DateTimeFormat format = DateTimeFormat.getFormat("dd.MM.yyyy");
				return format.format(object.getLoanedUntil());
			}
		};

		loanedMoviesTable.addColumn(titleColumn, "Title");
		loanedMoviesTable.addColumn(timeColumn, "Time");
		loanedMoviesTable.addColumn(categoryColumn, "Category");
		loanedMoviesTable.addColumn(ratingColumn, "Rating");
		loanedMoviesTable.addColumn(loanedUntilColumn, "Return Date");

		titleColumn.setSortable(true);
		timeColumn.setSortable(true);
		ratingColumn.setSortable(true);
		categoryColumn.setSortable(true);
		loanedUntilColumn.setSortable(true);

		ListHandler<Movie> sortHandler = new ListHandler<Movie>(
				loanedMovieProvider.getList());
		loanedMoviesTable.addColumnSortHandler(sortHandler);

		sortHandler.setComparator(titleColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				return o1.getTitle().compareTo(o2.getTitle());
			}
		});

		sortHandler.setComparator(timeColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				if (o1.getTime() > o2.getTime()) {
					return 1;
				}
				if (o1.getTime() < o2.getTime()) {
					return -1;
				}
				return 0;
			}
		});

		sortHandler.setComparator(categoryColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				return o1.getCategory().name()
						.compareTo(o2.getCategory().name());
			}
		});

		sortHandler.setComparator(ratingColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				if (o1.getRating().ordinal() > o2.getRating().ordinal()) {
					return 1;
				}
				if (o1.getRating().ordinal() < o2.getRating().ordinal()) {
					return -1;
				}
				return 0;
			}
		});

		sortHandler.setComparator(loanedUntilColumn, new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				return o1.getLoanedUntil().compareTo(o2.getLoanedUntil());
			}
		});

		loansPanel.add(loanedMoviesTable);
	}

	// Show this page
	public void show() {
		setVisible(true);
	}

	// Removes existing widgets from the web-page.
	private void clear() {
		RootPanel.get("content").clear();
	}

	// Callback to Return loaned movies.
	private class ReturnLoanCallback implements AsyncCallback<Void> {

		private Movie toReturn;

		public ReturnLoanCallback(Movie movieToReturn) {
			toReturn = movieToReturn;
		}

		@Override
		public void onFailure(Throwable caught) {
			GWT.log(caught.getMessage());
		}

		@Override
		public void onSuccess(Void result) {
			loanedMoviesList.remove(toReturn);
			updateTables();
		}

	}

}
