package movies.client.service;

import java.util.List;

import movies.web.model.Movie;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface MovieManagerServiceAsync {

	void listLoanableMovies(AsyncCallback<List<Movie>> callback);

	void listLoanedMovies(AsyncCallback<List<Movie>> callback);

	void loanMovie(Movie movie, AsyncCallback<Void> callback);

	void returnMovie(Movie movie, AsyncCallback<Void> callback);

}
