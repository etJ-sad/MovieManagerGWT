package movies.client.service;

import java.util.List;

import movies.web.model.Movie;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("moviemanagerservice")
public interface MovieManagerService extends RemoteService {

	/**
	 * Operation to list all loanable movies.
	 * */
	public List<Movie> listLoanableMovies();

	/**
	 * Operation to list all loaned movies.
	 * */
	public List<Movie> listLoanedMovies();

	/**
	 * Operation to loan a movie.
	 * */
	public void loanMovie(Movie movie);

	/**
	 * Operation to return a loaned movie.
	 * */
	public void returnMovie(Movie movie);

}
