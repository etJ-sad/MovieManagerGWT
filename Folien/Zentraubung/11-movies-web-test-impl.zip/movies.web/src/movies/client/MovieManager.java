package movies.client;

import java.util.List;

import movies.client.service.MovieManagerService;
import movies.client.service.MovieManagerServiceAsync;
import movies.client.ui.LoansView;
import movies.web.model.Movie;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class MovieManager implements EntryPoint {

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {

		final MovieManagerServiceAsync movieService = GWT
				.create(MovieManagerService.class);

		// Call list loaned movies and show view
		movieService.listLoanedMovies(new AsyncCallback<List<Movie>>() {

			@Override
			public void onSuccess(List<Movie> result) {
				LoansView loansView = new LoansView(result);
				loansView.initialize();
				loansView.show();
			}

			@Override
			public void onFailure(Throwable caught) {
				GWT.log(caught.getMessage());
			}
		});

	}

}
