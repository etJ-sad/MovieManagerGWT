package movies.web.test;

import java.util.List;

import junit.framework.TestCase;
import movies.server.MovieManagerServiceImpl;
import movies.web.model.Movie;

// To run this test:
//
// 1. Start the Movie Manager Server
// 2. Start the Movie Manager Client
// 3. Create suitable test data within the Movie Manager Client and Server
// 4. Open the file EMFStoreConnector.product in project movies.emfstore: 
//    In the tab Overview select "Launch an Eclipse application"
// 5. Execute this test: "Run as >> JUnit Test"
public class TestMovieManagerServiceImpl extends TestCase {

	// stub
	private MovieManagerServiceImpl service;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		service = new MovieManagerServiceImpl();
	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		service = null;
	}

	/**
	 * Infrastructure: At least one loanable movie must exist in the Movie
	 * Manager application.
	 * */
	public void testLoanAndReturnMovie() {
		// Use the service to get all loanable movies from the Movie Manager
		// application
		List<Movie> loanableMovies = service.listLoanableMovies();

		// Precondition Loan: movies are loanable & not loaned
		for (Movie movie : loanableMovies) {
			assertTrue(movie.isLoanable());
			assertFalse(movie.isLoaned());
		}

		// Test Loan
		for (Movie movie : loanableMovies) {
			// Optional the return date can be set
			// movie.setLoanedUntil(new Date());
			service.loanMovie(movie);
		}

		// Postcondition Loan: movies are loanable & loaned
		for (Movie movie : service.listLoanedMovies()) {
			assertTrue(movie.isLoanable());
			assertTrue(movie.isLoaned());
		}
		// In addition check if all loanable movies are loaned
		assertTrue(service.listLoanableMovies().isEmpty());

		// Use the service to get all loaned movies from the Movie Manager
		// application
		List<Movie> loanedMovies = service.listLoanedMovies();

		// Precondition Return: movies are loanable & loaned
		for (Movie movie : loanedMovies) {
			assertTrue(movie.isLoanable());
			assertTrue(movie.isLoaned());
		}

		// Test Return
		for (Movie movie : loanedMovies) {
			service.returnMovie(movie);
		}

		// Postcondition Return: movies are loanable & not loaned
		for (Movie movie : service.listLoanableMovies()) {
			assertTrue(movie.isLoanable());
			assertFalse(movie.isLoaned());
		}
		// In addition check if all loaned movies are returned
		assertTrue(service.listLoanedMovies().isEmpty());
	}

}
