package movies.test;

import movies.Movie;
import movies.MoviesFactory;
import junit.framework.TestCase;

public class UnMarkMovieLoanable extends TestCase {

	// stub
	private Movie movie;

	// Test mark and unmark on a movie when a movie is not loaned
	public void testMovieLoanableNotLoaned() {
		// Precondition 1: loanable = false & loaned = false
		movie.setLoanable(false);
		movie.setLoaned(false);

		// Test mark
		movie.setLoanable(true);

		// Postcondition 1: loanable = true & loaned = false
		assertTrue(movie.isLoanable());
		assertFalse(movie.isLoaned());

		// Precondition 2 = Postcondition 1: loanable = true & loaned = false
		// Test mark again
		movie.setLoanable(true);

		// Postcondition 2: loanable = true & loaned = false
		assertTrue(movie.isLoanable());
		assertFalse(movie.isLoaned());

		// Precondition 3 = Postcondition 2: loanable = true & loaned = false

		// Test unmark
		movie.setLoanable(false);

		// Postcondition 3: loanable = false & loaned = false
		assertFalse(movie.isLoanable());
		assertFalse(movie.isLoaned());
		
		// Precondition 4 = Postcondition 3: loanable = false & loaned = false
		
		// Test unmark again
		movie.setLoanable(false);

		// Postcondition 5: loanable = false & loaned = false
		assertFalse(movie.isLoanable());
		assertFalse(movie.isLoaned());
	}

	public void testMovieLoanableLoaned() {
		// Precondition 1: loanable = true & loaned = true
		movie.setLoanable(true);
		movie.setLoaned(true);
		
		// Test mark
		movie.setLoanable(true);
		
		// Postcondtion 1: loanable = true & loaned = true
		assertTrue(movie.isLoanable());
		assertTrue(movie.isLoaned());
		
		// Precondition 2 = Postcondition 1: loanable = true & loaned = true
		
		// Teste unmark
		try {
			movie.setLoanable(false);
			// Force JUnit to fail if no exception was thrown.
			fail("Expected exception");
		} catch (RuntimeException e) {
			assertEquals(e.getMessage().toString(), "The movie cannot be unmarked, because it is currently loaned.");
		}
		
		// Postcondition 3: loanable = true & loaned = true
		assertTrue(movie.isLoanable());
		assertTrue(movie.isLoaned());
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		movie = MoviesFactory.eINSTANCE.createMovie();
	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		movie = null;
	}
}
