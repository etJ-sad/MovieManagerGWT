package movies.web.model;

public enum MovieCategory {
	Action, ScienceFiction, Comedy, Music, Drama, Thriller, Horror, Fantasy, Adventure, Romance, Documentation;
}
