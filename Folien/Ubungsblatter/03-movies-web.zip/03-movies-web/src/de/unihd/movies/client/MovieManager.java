package de.unihd.movies.client;

import com.google.gwt.core.client.EntryPoint;

/**
 * The Class MovieManager.
 */
public class MovieManager implements EntryPoint {

	public void onModuleLoad() {

	}
	
}
