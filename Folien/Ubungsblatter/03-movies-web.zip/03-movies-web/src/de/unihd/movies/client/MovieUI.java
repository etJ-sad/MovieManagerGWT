package de.unihd.movies.client;

import java.util.ArrayList;

import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * MovieUI that contains a table of movies.
 * */
public class MovieUI extends Composite {

	/**
	 * The main panel which contain all other widgets
	 * */
	private VerticalPanel panel;

	/**
	 * Creates a MovieUI with the given list of movies.
	 * 
	 * @param movies
	 *            The list of movies to show.
	 * */
	public MovieUI(ArrayList<Movie> movies) {

		panel = new VerticalPanel();

		// Create a table containing all movies
		CellTable<Movie> movieTable = new CellTable<Movie>();
		
		// Add the table to the panel
		panel.add(movieTable);
	}

	/**
	 * Shows the content of the MovieUI.
	 * */
	public void show() {
		initWidget(panel);
		RootPanel.get("content").add(this);
		this.setVisible(true);
	}

}
