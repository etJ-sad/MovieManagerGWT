package org.movie.test;

import junit.framework.TestCase;

import org.movie.Gender;
import org.movie.Movie;
import org.movie.Performer;

/**
 * The Class MovieOverallRatingTest.
 */
public class MovieOverallRatingTest extends TestCase {
	
	/** The movie. */
	private Movie movie = null;
	
	/** The performer1. */
	private Performer performer1 = null;
	
	/** The performer2. */
	private Performer performer2 = null;
	
	/** The performer3. */
	private Performer performer3 = null;
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	@Override
	public void setUp() throws Exception {
		super.setUp();
		
		movie = new Movie("Movie 1", 10, 3);
		performer1 = new Performer("John Doe", Gender.MALE, 0);
		performer2 = new Performer("Jane Doe", Gender.FEMALE, 3);
		performer3 = new Performer("Max Power", Gender.MALE, 2);
		movie.addPerformer(performer1);
		movie.addPerformer(performer2);
		movie.addPerformer(performer3);
	}
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		
		movie = null;
		performer1 = null;
		performer2 = null;
		performer3 = null;
	}
	
	// Testcase #1: MovieRating < 0
    //              All elements in RatingPerformer have valid values
	public void testOverallRatingMovieRatingTooLow() {
        System.out.println("Start Testcase 1");
        
        movie.setRating(-1);
        boolean exceptionCaught = false;
        int overallRating = 1;
        
        try {
            System.out.println("Calculating overallRating");
            
            // !!! most important line of code: TESTING METHOD overallRating !!!
            overallRating = movie.overallRating();
            
            System.out.println("overallRating: " + overallRating);
        } catch (Exception e) {         
            exceptionCaught = true;
            e.printStackTrace();
        }       
        
        assertNotNull(movie);
        assertNotNull(performer1);
        assertFalse(exceptionCaught);
        
        assertTrue(movie.getTitle().equals("Movie 1"));
        assertTrue(movie.getTime() == 10);
        assertTrue(movie.getPerformers().size() == 3);
        
        assertFalse(overallRating == 1);
        assertTrue(overallRating == -1);
        
        System.out.println("End Testcase 1\n");
	}
	
	/**
	 * Test overall rating another test method.
	 */
	public void testOverallRatingAnotherTestMethod() {
		// TODO starting point of implementation for Students :-)
	}
	
	// TODO more test methods
}
