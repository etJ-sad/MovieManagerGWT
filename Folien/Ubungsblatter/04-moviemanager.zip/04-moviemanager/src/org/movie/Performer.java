package org.movie;

/**
 * The Class Performer.
 */
public class Performer {
	
	/** The outstanding. */
	private boolean outstanding;
	
	/** The name. */
	private String name;
	
	/** The gender. */
	private Gender gender;
	
	/** The rating. */
	private int rating; 
	
	/** The movie. */
	private Movie movie;

	/**
	 * Instantiates a new performer.
	 *
	 * @param pName the name
	 * @param pGender the gender
	 * @param pRating the rating
	 */
	public Performer(String pName, Gender pGender, int pRating) {
		this.name = pName;
		this.gender = pGender;
		this.rating = pRating;
		this.outstanding = false;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param pName the new name
	 */
	public void setName(String pName) {
		this.name = pName;
	}
	
	/**
	 * Gets the gender.
	 *
	 * @return the gender
	 */
	public Gender getGender() {
		return gender;
	}

	/**
	 * Sets the gender.
	 *
	 * @param pGender the new gender
	 */
	public void setGender(Gender pGender) {
		this.gender = pGender;
	}
	
	/**
	 * Gets the rating.
	 *
	 * @return the rating
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * Sets the rating.
	 *
	 * @param pRating the new rating
	 */
	public void setRating(int pRating) {
		this.rating = pRating;
	}
	
	/**
	 * Gets the movie.
	 *
	 * @return the movie
	 */
	public Movie getMovie() {
		return movie;
	}

	/**
	 * Sets the movie.
	 *
	 * @param pMovie the new movie
	 */
	public void setMovie(Movie pMovie) {
		this.movie = pMovie;
	}
	
	/**
	 * Checks if is outstanding.
	 *
	 * @return true, if is outstanding
	 */
	public boolean isOutstanding() {
		return outstanding;
	}

	/**
	 * Sets the outstanding.
	 *
	 * @param pOutstanding the new outstanding
	 */
	public void setOutstanding(final boolean pOutstanding) {
		this.outstanding = pOutstanding;
	}
	
	/**
	 * Show information.
	 */
	public void showInformation() {
		System.out.println("Name: " + name);
		System.out.println("Gender: " + gender);
		System.out.println("Outstanding: " + outstanding);
	}
}
