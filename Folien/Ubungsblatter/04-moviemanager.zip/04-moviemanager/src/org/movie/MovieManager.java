package org.movie;

public final class MovieManager {
	
	private MovieManager() {}
	
	public static void main(final String[] args) {
		Movie movie = new Movie("Oceans 11", 160, 5);
		movie.showInformation();
		
		System.out.println("Create performers and associate them to the movie"); 
		String performers[] = { "George Clooney", "Brad Pitt", "Julia Roberts"};
		Gender gender[] = {Gender.MALE, Gender.MALE, Gender.FEMALE };
		for (int i = 0; i < Math.min(performers.length, gender.length); i++) {
			movie.addPerformer(new Performer(performers[i], gender[i], 5)); 
		}

		Performer outstanding = movie.getPerformer(performers[0]);
		outstanding.setOutstanding(true);
		
		System.out.println("Showing only outstanding performers"); 
		for (Performer performer : movie.getAllOutstandingPerformers()) {
			performer.showInformation();
		}
		
		System.out.println("All Movie Performers ..."); 
		for (Performer performer : movie.getPerformers()) {
			performer.showInformation();
		}

		System.out.println("Delete all performers ..."); 
		movie.deleteAllPerformers();
		
		System.out.println("Done! (Performer size: " + movie.getPerformers().size() + ")"); 
	}
}
