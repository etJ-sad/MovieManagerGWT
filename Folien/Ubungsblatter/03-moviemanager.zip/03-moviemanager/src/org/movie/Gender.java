package org.movie;

/**
 * The Enum Gender.
 */
public enum Gender {

	/** The male. */
	MALE,
	/** The female. */
	FEMALE;
}
