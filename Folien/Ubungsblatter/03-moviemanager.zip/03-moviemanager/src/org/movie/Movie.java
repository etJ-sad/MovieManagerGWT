package org.movie;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * The Class Movie.
 */
public class Movie {
	
	/** The title. */
	private String title;
	
	/** The time. */
	private int time;
	
	/** The rating. */
	private int rating;
	
	/** The number. */
	private final transient int number;
	
	/** The nextnumber. */
	private static int nextnumber = 0;
	
	/** The performers. */
	private final Set<Performer> performers;

	/**
	 * Instantiates a new movie.
	 */
	public Movie() {
		this.number = nextnumber++;
		performers = new HashSet<Performer>();
	}
	
	/**
	 * Instantiates a new movie.
	 *
	 * @param pTitle the title
	 * @param pTime the time
	 * @param pRating the rating
	 */
	public Movie(String pTitle, int pTime, int pRating) {
		this.title = pTitle;
		this.time = pTime;
		this.rating = pRating;
		this.number = nextnumber++;
		performers = new HashSet<Performer>();
	}

	/**
	 * Adds the performer.
	 *
	 * @param performer the performer
	 */
	public void addPerformer(Performer performer) {
		performer.setMovie(this);
		performers.add(performer);
	}

	/**
	 * Gets the performer.
	 *
	 * @param name the name
	 * @return the performer
	 */
	public Performer getPerformer(String name) {
		Performer temp = null;
		for (Performer performer : performers) {
			if (performer.getName().equals(name)) {
				temp = performer;
			}
		}
		return temp;
	}
	
	/**
	 * Gets the all outstanding performers.
	 *
	 * @return the all outstanding performers
	 */
	public Set<Performer> getAllOutstandingPerformers() {
		HashSet<Performer> temp = new HashSet<Performer>();
		for (Performer performer : performers) {
			if (performer.isOutstanding()) {
				temp.add(performer);
			}
		}
		return temp;
	}

	/**
	 * Gets the performers.
	 *
	 * @return the performers
	 */
	public Set<Performer> getPerformers() {
		return performers;
	}

	/**
	 * Delete performer.
	 *
	 * @param performer the performer
	 * @return true, if successful
	 */
	public boolean deletePerformer(Performer performer) {
		return performers.remove(performer);
	}

	/**
	 * Delete all performers.
	 *
	 * @return true, if successful
	 */
	public boolean deleteAllPerformers() {
		return performers.removeAll(performers);
	}

	/**
	 * Gets the title.
	 *
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the title.
	 *
	 * @param title the new title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public int getTime() {
		return time;
	}

	/**
	 * Sets the time.
	 *
	 * @param pTime the new time
	 */
	public void setTime(int pTime) {
		this.time = pTime;
	}
	
	/**
	 * Gets the rating.
	 *
	 * @return the rating
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * Sets the rating.
	 *
	 * @param pRating the new rating
	 */
	public void setRating(int pRating) {
		this.rating = pRating;
	}

	/**
	 * Gets the number.
	 *
	 * @return the number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * Show information.
	 */
	public void showInformation() {
		System.out.println("Title: " + this.title);
		System.out.println("Time: " + this.time);
		System.out.println("Number: " + this.number);
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(final String[] args) {
		final Movie movie1 = new Movie("Testfilm 1", 10, 3);
		final Movie movie2 = new Movie("Testfilm 2", 20, 4);
		final Performer perf1 = new Performer("John Doe", Gender.MALE, 0);
		final Performer perf2 = new Performer("Jane Doe", Gender.FEMALE, 3);
		perf1.setMovie(movie1);
		perf2.setMovie(movie2);
		movie1.showInformation();
		movie2.showInformation();
	}
	
	/**
	 * Gets the rating performers.
	 *
	 * @return the rating performers
	 */
	public ArrayList<Integer> getRatingPerformers() {
		ArrayList<Integer> ratingPerformers = new ArrayList<Integer>();
		for (Performer p : performers) {
			ratingPerformers.add(new Integer(p.getRating()));
		}
		return ratingPerformers;
	}
	
	/**
	 * Returns the overall rating. The overall rating is calculated as:
	 *   ratingMovie + max of ratingPerformers.
	 * 'ratingMovie' needs to be between 0 and 5.
	 * All elements in the list 'ratingPerformers' needs to be between 0 and 5.
	 * The overall rating is between 0 and 10.
	 * 
	 * @return overallRating between 0 and 10. -1 if any input parameter is out of range
	 */
	public int overallRating() {
		
		// The single rating of the movie
		int ratingMovie = this.getRating();
		
		// List containing the ratings of performers
		ArrayList<Integer> ratingPerformers = this.getRatingPerformers();
		
		// the maximum that is found by the Algorithm
		Integer maxRatingPerformer = 0;
		// check if parameters are not null
		if (/*ratingMovie == null ||*/ ratingPerformers == null) {
			return -1;
		}
		// check range of ratingMovie
		if (ratingMovie < 0 || ratingMovie > 5) {
			return -1;
		}
		int i;
		for (i=0; i < ratingPerformers.size(); i++) {
			// check range of each element of the list of ratingPerformers
			if (ratingPerformers.get(i) < 0 || ratingPerformers.get(i) > 5) {
				return -1;
			}
			// assign maximum if found
			if (ratingPerformers.get(i) > maxRatingPerformer) {
				maxRatingPerformer = ratingPerformers.get(i);
			}
		}
		if (i > ratingPerformers.size()) {
			return -2;
		}
		return -1;
	}
	
}
