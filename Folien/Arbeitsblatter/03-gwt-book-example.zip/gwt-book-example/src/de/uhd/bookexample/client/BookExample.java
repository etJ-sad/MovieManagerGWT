package de.uhd.bookexample.client;

import com.google.gwt.core.client.EntryPoint;

/**
 * A simple web application showing a list of books.
 * */
public class BookExample implements EntryPoint {

	@Override
	public void onModuleLoad() {

	}
}
