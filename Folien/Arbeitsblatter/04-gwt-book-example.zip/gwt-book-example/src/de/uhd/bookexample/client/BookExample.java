package de.uhd.bookexample.client;

import java.util.ArrayList;

import com.google.gwt.core.client.EntryPoint;

/**
 * A simple web application showing a list of books.
 * */
public class BookExample implements EntryPoint { // <- WebApp Startpunkt

	@Override
	public void onModuleLoad() { // <- aequivalent zur main() in Java-Programmen

		ArrayList<Book> bookList = new ArrayList<Book>();
		bookList.add(new Book(1234, "Krieg und Frieden", "Leo Tolstoi",
				"Springer"));
		bookList.add(new Book(4567, "Die Tore der Welt", "Ken Follet", "dpunkt"));
		bookList.add(new Book(6789, "Illuminati", "Dan Brown", "Luebbe"));

		new BookUI(bookList);
	}
}
