package de.uhd.bookexample.client;

import java.io.Serializable;

/**
 * A simple book class.
 * */
public class Book implements Serializable{ // <- DAS MUSS ergaenzt werden!!!

	/**
	 * Unique ID.
	 */
	private static final long serialVersionUID = -5252412272079285592L;

	/**
	 * The identification number of a book
	 * */
	private int isbn;

	/**
	 * The title of a book
	 * */
	private String title;

	/**
	 * The name of the book's author
	 * */
	private String author;

	/**
	 * The publisher of the book
	 * */
	private String publisher;

	/**
	 * Creates a new book with default attributes.
	 * */
	public Book() {
		isbn = 0;
		title = "";
		author = "";
		publisher = "";
	}

	/**
	 * Creates a new book with the given attributes.
	 * 
	 * @param isbn
	 *            The identification number of the book
	 * @param title
	 *            The book's title
	 * @param author
	 *            The book's author
	 * @param publisher
	 *            The book's publisher
	 * */
	public Book(int isbn, String title, String author, String publisher) {
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.publisher = publisher;
	}

	/**
	 * @return the isbn
	 */
	public int getIsbn() {
		return isbn;
	}

	/**
	 * @param isbn
	 *            the isbn to set
	 */
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author
	 *            the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the publisher
	 */
	public String getPublisher() {
		return publisher;
	}

	/**
	 * @param publisher
	 *            the publisher to set
	 */
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

}
