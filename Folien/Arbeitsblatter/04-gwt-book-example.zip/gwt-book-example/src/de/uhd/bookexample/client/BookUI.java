package de.uhd.bookexample.client;

import java.util.ArrayList;
import java.util.Comparator;

import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.TextCell;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.ListDataProvider;

public class BookUI {

	/**
	 * Provider that is able to apply a filter text
	 * */
	private ListDataProvider<Book> bookDataProvider;

	/**
	 * The list of all books
	 * */
	private ArrayList<Book> bookList;

	public BookUI(ArrayList<Book> books) {
		bookList = books;
		
		RootPanel rootPanel = RootPanel.get("content");

		VerticalPanel vp = new VerticalPanel();
		HTML weppageHeader = new HTML("<h1>BookExample</h1>");
		vp.add(weppageHeader);

		CellTable<Book> bookTable = new CellTable<Book>();

		HorizontalPanel hp = new HorizontalPanel();

		Label filterLabel = new Label("Filter:");
		hp.add(filterLabel);

		final TextBox filterText = new TextBox();
		hp.add(filterText);

		Button addBook = new Button("Add");
		hp.add(addBook);

		Button deleteBook = new Button("Delete");
		hp.add(deleteBook);

		vp.add(hp);
		vp.add(bookTable);
		rootPanel.add(vp);

		Column<Book, String> isbnColumn = new Column<Book, String>(
				new TextCell()) {

			@Override
			public String getValue(Book object) {
				return "" + object.getIsbn();
			}

		};
		bookTable.addColumn(isbnColumn, "ISBN");

		Column<Book, String> titleColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getTitle();
			}
		};
		bookTable.addColumn(titleColumn, "Title");

		Column<Book, String> authorColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getAuthor();
			}
		};
		bookTable.addColumn(authorColumn, "Author");

		Column<Book, String> publisherColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getPublisher();
			}
		};
		bookTable.addColumn(publisherColumn, "Publisher");

		bookDataProvider = new ListDataProvider<Book>();
		bookDataProvider.addDataDisplay(bookTable);
		bookDataProvider.setList(bookList);

		isbnColumn.setSortable(true);
		titleColumn.setSortable(true);
		authorColumn.setSortable(true);
		publisherColumn.setSortable(true);

		ListHandler<Book> sortHandler = new ListHandler<Book>(
				bookDataProvider.getList());
		bookTable.addColumnSortHandler(sortHandler);

		sortHandler.setComparator(isbnColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				if (o1.getIsbn() > o2.getIsbn()) {
					return 1;
				}
				if (o1.getIsbn() < o2.getIsbn()) {
					return -1;
				}
				return 0;
			}
		});

		sortHandler.setComparator(titleColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				return o1.getTitle().compareTo(o2.getTitle());
			}
		});

		sortHandler.setComparator(authorColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				return o1.getAuthor().compareTo(o2.getAuthor());
			}
		});

		sortHandler.setComparator(publisherColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				return o1.getPublisher().compareTo(o2.getPublisher());
			}
		});

	}

}
