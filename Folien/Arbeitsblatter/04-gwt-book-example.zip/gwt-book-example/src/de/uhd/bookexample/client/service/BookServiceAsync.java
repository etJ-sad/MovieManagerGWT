package de.uhd.bookexample.client.service;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;

import de.uhd.bookexample.client.Book;

/**
 * The interface to provide callback methods for the {@link BookService}
 * 
 * @author Marcus Seiler
 * */
public interface BookServiceAsync {

	/**
	 * Callback to handle the books loading.
	 * 
	 * @param callback
	 *            The callback to handle the books loading.
	 * */
	void loadBooks(AsyncCallback<ArrayList<Book>> callback);

	/**
	 * Callback to handle the storage of books.
	 * 
	 * @param books
	 *            The list of books to be stored.
	 * @param callback
	 *            The callback to handle the books storage.
	 * */
	void saveBooks(ArrayList<Book> books, AsyncCallback<Void> callback);

}
