package de.uhd.bookexample.server;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import de.uhd.bookexample.client.Book;
import de.uhd.bookexample.client.service.BookService;

/**
 * Server-side implementation of the {@link BookService}.
 * 
 * @author Marcus Seiler
 * */
public class BookServiceImpl extends RemoteServiceServlet implements
		BookService {

	/**
	 * Unique ID
	 */
	private static final long serialVersionUID = 2610052049222392123L;
	
	/**
	 * The filename to store the books.
	 * */
	private String fileName = "books.ser";

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Book> loadBooks() {
		ArrayList<Book> books = new ArrayList<Book>();
		try {
			FileInputStream fileIn = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			books = (ArrayList<Book>) in.readObject();
			in.close();
			fileIn.close();
		} catch (FileNotFoundException e) {
			// if no file is found, create empty ArrayList
			books = new ArrayList<Book>();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return books;
	}

	@Override
	public void saveBooks(ArrayList<Book> books) {
		try {
			FileOutputStream fileOut = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(books);
			out.close();
			fileOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
