package de.hd.uni.ub.tutorial.junit;

public class Empty {

}
