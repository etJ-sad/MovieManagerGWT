package de.uhd.bookexample.client;

import java.util.ArrayList;
import java.util.Comparator;

import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.TextCell;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.ListDataProvider;

/**
 * A simple web application showing a list of books.
 * */
public class BookExample implements EntryPoint { // <- WebApp Startpunkt

	@Override
	public void onModuleLoad() { // <- aequivalent zur main() in Java-Programmen

		// In der HTML-Datei haben wir eine zentrierte Tabelle eingefuegt.
		// In diese Tabelle wollen wir die Inhalte unserer Webanwendung
		// einfuegen.

		// Zugriff auf <td id="content"></td> in der HTML-Datei um darin dann
		// alle weiteren Inhalte einfuegen zu koennen.
		RootPanel rootPanel = RootPanel.get("content");

		// Zuerst legen wir ein neues Panel an. In das Panel packen wir unsere
		// Sachen rein. Es gibt unterschiedliche Panel aber fuer uns reicht das
		// vertikale Panel aus
		VerticalPanel vp = new VerticalPanel();

		// Wir wollen die Ueberschrift 'BookTable' hinzufuegen. Dazu legen wir
		// ein Widget vom Typ HTML an. In solch ein Widget kann man
		// herkoemmlichen HTML-Tags verwenden, z.B. h1.
		HTML weppageHeader = new HTML("<h1>BookExample</h1>");

		// Die Ueberschrift fuegen wir dem Panel hinzu
		vp.add(weppageHeader);

		// Wir wollen ein horizontales Panel anlegen
		HorizontalPanel hp = new HorizontalPanel();

		// Jetzt wollen wir einen Text anzeigen und wieder zum Panel hinzufuegen
		Label newBookName = new Label("Bookname:");
		hp.add(newBookName);

		// Um den Namen eines Buches einzugeben, brauchen wir eine TextBox.
		// Die TextBox wird auch wieder zum Panel hinzugefuegt.
		TextBox bookName = new TextBox();
		hp.add(bookName);

		// Um ein neues Buch einzufuegen brauchen wir einen Button.
		// Den Button fuegen wir wieder zum Panel hinzu.
		Button addBook = new Button("Add");
		hp.add(addBook);

		// Das horizontale Panel fuegen wir zu dem vertikalen Panel hinzu.
		vp.add(hp);

		// Wir fuegen das Panel zum 'Root' hinzu
		rootPanel.add(vp);

		// Erstellen wir uns eine Liste mit Buechern
		ArrayList<Book> bookList = new ArrayList<Book>();
		bookList.add(new Book(1234, "Krieg und Frieden", "Leo Tolstoi"));
		bookList.add(new Book(4567, "Die Tore der Welt", "Ken Follet"));
		bookList.add(new Book(6789, "Illuminati", "Dan Brown"));

		// Diese Liste wollen wir in einer Tabelle anzeigen.
		CellTable<Book> bookTable = new CellTable<Book>();
		vp.add(bookTable);

		// Jetzt legen wir die Spalten der Tabelle an.
		// Zuerst die Spalte fuer die ISBN
		// Eine TextCell ist nicht bearbeitbar!
		Column<Book, String> isbnColumn = new Column<Book, String>(
				new TextCell()) {

			@Override
			public String getValue(Book object) {
				// Hier muss der/das Wert/Attribute zurueckgegeben werden, der
				// in der Spalte stehen soll.
				return "" + object.getIsbn();
			}

		};

		// Die ISBN Spalte fuegen wir der Tabelle hinzu.
		bookTable.addColumn(isbnColumn, "ISBN");

		// Jetzt noch eine Spalte fuer den Titel
		// In einer EditTextCell kann man den Text bearbeiten!
		Column<Book, String> titleColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getTitle();
			}
		};

		// Auch die Spalte wieder der Tabelle hinzufuegen.
		bookTable.addColumn(titleColumn, "Title");

		// Und eine Spalte fuer den Author
		Column<Book, String> authorColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getAuthor();
			}
		};

		// Auch die Spalte wieder der Tabelle hinzufuegen.
		bookTable.addColumn(authorColumn, "Author");

		// Um die oben erstellten Liste von Buechern in die Tabelle zubekommen
		// erstellen wir einen ListDataProvider. Dem sagen wir welche Tabelle er
		// darstellen soll und was die Inhalte der Tabelle sind.
		ListDataProvider<Book> bookDataProvider = new ListDataProvider<Book>();
		bookDataProvider.addDataDisplay(bookTable);
		bookDataProvider.setList(bookList);

		// Jetzt wollen wir, dass wir alle Spalten sortieren koennen.
		// Dazu setzen wir jede Spalten auf sortierbar.
		isbnColumn.setSortable(true);
		titleColumn.setSortable(true);
		authorColumn.setSortable(true);

		// Dann brauchen wir einen Handler, der den Event des Sortierens
		// abfangen kann. Der Handler bekommt die List des DataProviders
		// uebergeben. Den Handler fuegen wir an die Tabelle an.
		ListHandler<Book> sortHandler = new ListHandler<Book>(
				bookDataProvider.getList());
		bookTable.addColumnSortHandler(sortHandler);

		// Um zu Sortieren muss der Handler die Buecher vergleichen.
		// Wir legen einen Comparator an, der uns die Spalte ISBN vergleicht.
		sortHandler.setComparator(isbnColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die isbn
				if (o1.getIsbn() > o2.getIsbn()) {
					return 1;
				}
				if (o1.getIsbn() < o2.getIsbn()) {
					return -1;
				}
				return 0;
			}
		});

		// Dann brauchen wir eine Comparator fuer die Titel-Spalte.
		sortHandler.setComparator(titleColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die Titel der Buecher.
				// Der Datentyp String bietet bereits eine Vergleichsoperation.
				return o1.getTitle().compareTo(o2.getTitle());
			}
		});

		// Zum Schluss wollen wir auch noch anhand der Authoren sortieren.
		sortHandler.setComparator(authorColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die Authoren.
				return o1.getAuthor().compareTo(o2.getAuthor());
			}
		});
	}
}
