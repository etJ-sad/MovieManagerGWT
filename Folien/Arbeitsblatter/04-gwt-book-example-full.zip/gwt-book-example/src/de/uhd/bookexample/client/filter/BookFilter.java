package de.uhd.bookexample.client.filter;

import de.uhd.bookexample.client.Book;

/**
 * A filter for {@link Book}. The filter is valid if the title of a book
 * contains the filter text.
 * */
public class BookFilter implements IFilter<Book> {

	@Override
	public boolean isValid(Book value, String filter) {
		return value.getTitle().toLowerCase().contains(filter.toLowerCase());
	}

}
