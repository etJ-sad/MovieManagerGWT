package de.uhd.bookexample.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

import com.google.gwt.cell.client.EditTextCell;
import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.cell.client.SelectionCell;
import com.google.gwt.cell.client.TextCell;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.SingleSelectionModel;

import de.uhd.bookexample.client.filter.BookFilter;
import de.uhd.bookexample.client.filter.FilteredListDataProvider;
import de.uhd.bookexample.client.service.BookService;
import de.uhd.bookexample.client.service.BookServiceAsync;

public class BookUI {

	/**
	 * Provider that is able to apply a filter text
	 * */
	private FilteredListDataProvider<Book> bookDataProvider;

	/**
	 * The list of all books
	 * */
	private ArrayList<Book> bookList;

	/**
	 * The service to connect to the server side BookService.
	 * */
	private final BookServiceAsync bookService = GWT.create(BookService.class);

	public BookUI(ArrayList<Book> books) {
		bookList = books;
		
		// In der HTML-Datei haben wir eine zentrierte Tabelle eingefuegt.
		// In diese Tabelle wollen wir die Inhalte unserer Webanwendung
		// einfuegen.

		// Zugriff auf <td id="content"></td> in der HTML-Datei um darin dann
		// alle weiteren Inhalte einfuegen zu koennen.
		RootPanel rootPanel = RootPanel.get("content");

		// Zuerst legen wir ein neues Panel an. In das Panel packen wir unsere
		// Sachen rein. Es gibt unterschiedliche Panel aber fuer uns reicht das
		// vertikale Panel aus
		VerticalPanel vp = new VerticalPanel();

		// Wir wollen die Ueberschrift 'BookTable' hinzufuegen. Dazu legen wir
		// ein Widget vom Typ HTML an. In solch ein Widget kann man
		// herkoemmlichen HTML-Tags verwenden, z.B. h1.
		HTML weppageHeader = new HTML("<h1>BookExample</h1>");

		// Die Ueberschrift fuegen wir dem Panel hinzu
		vp.add(weppageHeader);

		// Diese Liste wollen wir in einer Tabelle anzeigen.
		CellTable<Book> bookTable = new CellTable<Book>();

		// Wir wollen ein horizontales Panel anlegen
		HorizontalPanel hp = new HorizontalPanel();

		// Jetzt wollen wir einen Text anzeigen und wieder zum Panel hinzufuegen
		Label filterLabel = new Label("Filter:");
		hp.add(filterLabel);

		// Um nach Buechern zu filtern, brauchen wir eine TextBox.
		// Die TextBox wird auch wieder zum Panel hinzugefuegt.
		final TextBox filterText = new TextBox();
		// Wir wollen nur die Buecher anzeigen deren Titel dem eingegebenen
		// Filtertext entsprechen. Dazu verwenden wir den ValueChangeHandler,
		// der wird aufgerufen wenn man in einer TextBox die <ENTER>-Taste
		// drueckt.
		filterText.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> event) {
				// Beim Druecken von <ENTER> setzen wir den Filtertext
				bookDataProvider.setFilter(filterText.getText());
			}
		});
		hp.add(filterText);

		// Um ein neues Buch einzufuegen brauchen wir einen Button.
		// Den Button fuegen wir wieder zum Panel hinzu.
		Button addBook = new Button("Add");
		// Bei einem Klick auf den Button soll ein neues Buch in die Liste
		// eingetragen werden. Fuer Interaktionen auf Buttons verwendet man den
		// ClickHandler.
		addBook.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				// Hier erstellen wir ein neues Buch
				// Ich verwende hier Zufallszahlen
				Random random = new Random();
				int nextISBN = random.nextInt(10000);

				Book book = new Book(nextISBN, "", "", "");
				// Das Buch fuegen wir in die Liste ein
				bookList.add(book);

				// Wenn wir ein Buch hinzufuegen sollen die Buecher auch
				// auf dem Server gespeichert werden.
				saveBooks();

				// Zum Schluss updaten wir den DataProvider und die Tabelle
				updateTable();
			}
		});
		hp.add(addBook);

		// Um eine einzelne Zeile auszuwaehlen verwenden wir das
		// SingleSelectionModel und fuegen es zur Tabelle hinzu (siehe
		// unten)
		final SingleSelectionModel<Book> selection = new SingleSelectionModel<Book>();
		bookTable.setSelectionModel(selection);

		// Um ein Buch zu loeschen brauchen wir wieder einen Button.
		// Den Button fuegen wir zum Panel hinzu.
		Button deleteBook = new Button("Delete");
		// Bei einem Klick auf den Button soll die aktuell selektierte
		// Zeile geloescht werden. Wir verwenden wieder den ClickHandler.
		deleteBook.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				// Nur wenn eine Zeile markiert ist koennen wir Loeschen
				// Zudem merken wir uns das zu loeschende Buch
				Book toDelete = null;
				for (Book current : bookList) {
					if (selection.isSelected(current)) {
						toDelete = current;
						// Hier koennen wir die Schleife abbrechen, da
						// immer nur ein Buch selektiert werden kann
						break;
					}
				}

				// Wenn das Buch nicht null ist, d.h. wenn eine Zeile
				// selektiert wurde, kann man das Buch loeschen
				if (toDelete != null) {
					bookList.remove(toDelete);

					// Wenn wir ein Buch loeschen sollen die Buecher auch
					// auf dem Server geloescht werden.
					saveBooks();

					// Anschliessend wieder ein Refresh
					updateTable();
				}
			}
		});
		hp.add(deleteBook);

		// Das horizontale Panel fuegen wir zu dem vertikalen Panel hinzu.
		vp.add(hp);

		// Hier fuegen wir die Tabelle ein
		vp.add(bookTable);

		// Wir fuegen das Panel zum 'Root' hinzu
		rootPanel.add(vp);

		// Jetzt legen wir die Spalten der Tabelle an.
		// Zuerst die Spalte fuer die ISBN
		// Eine TextCell ist nicht bearbeitbar!
		Column<Book, String> isbnColumn = new Column<Book, String>(
				new TextCell()) {

			@Override
			public String getValue(Book object) {
				// Hier muss der/das Wert/Attribute zurueckgegeben werden, der
				// in der Spalte stehen soll.
				return "" + object.getIsbn();
			}

		};

		// Die ISBN Spalte fuegen wir der Tabelle hinzu.
		bookTable.addColumn(isbnColumn, "ISBN");

		// Jetzt noch eine Spalte fuer den Titel
		// In einer EditTextCell kann man den Text bearbeiten!
		Column<Book, String> titleColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getTitle();
			}
		};

		// Um den Text dauerhaft bearbeiten zu koennen haengen wir eine
		// FieldUpdater an die Spalte
		titleColumn.setFieldUpdater(new FieldUpdater<Book, String>() {

			@Override
			public void update(int index, Book object, String value) {
				object.setTitle(value);
				// Immer wenn wir ein Feld veraendern sollen alle Buecher
				// zum Server uebertragen werden.
				saveBooks();
				updateTable();
			}
		});

		// Auch die Spalte wieder der Tabelle hinzufuegen.
		bookTable.addColumn(titleColumn, "Title");

		// Und eine Spalte fuer den Author
		Column<Book, String> authorColumn = new Column<Book, String>(
				new EditTextCell()) {

			@Override
			public String getValue(Book object) {
				return object.getAuthor();
			}
		};

		// Auch fuer den Author
		authorColumn.setFieldUpdater(new FieldUpdater<Book, String>() {

			@Override
			public void update(int index, Book object, String value) {
				object.setAuthor(value);
				saveBooks();
				updateTable();
			}
		});

		// Auch die Spalte wieder der Tabelle hinzufuegen.
		bookTable.addColumn(authorColumn, "Author");

		// Der Publisher soll aus einer Drop-Down-Liste ausgewaehlt werden
		ArrayList<String> publisher = new ArrayList<String>(3);
		publisher.add("Springer");
		publisher.add("Luebbe");
		publisher.add("dpunkt");

		// Und eine Spalte fuer den Verlag
		// Um die DropDown-Liste anzuzeigen, verwenden wir die
		// SelectionCell
		Column<Book, String> publisherColumn = new Column<Book, String>(
				new SelectionCell(publisher)) {

			@Override
			public String getValue(Book object) {
				return object.getPublisher();
			}
		};

		// Auch die Spalte wieder der Tabelle hinzufuegen.
		bookTable.addColumn(publisherColumn, "Publisher");

		// Und fuer den Verlag
		publisherColumn.setFieldUpdater(new FieldUpdater<Book, String>() {

			@Override
			public void update(int index, Book object, String value) {
				object.setPublisher(value);
				saveBooks();
				updateTable();
			}
		});

		// Um die oben erstellten Liste von Buechern in die Tabelle zubekommen
		// erstellen wir einen ListDataProvider. Dem sagen wir welche Tabelle er
		// darstellen soll und was die Inhalte der Tabelle sind.
		// Den DataProvider habe ich ausgetauscht
		bookDataProvider = new FilteredListDataProvider<Book>(new BookFilter());
		bookDataProvider.addDataDisplay(bookTable);
		bookDataProvider.setList(bookList);

		// Jetzt wollen wir, dass wir alle Spalten sortieren koennen.
		// Dazu setzen wir jede Spalten auf sortierbar.
		isbnColumn.setSortable(true);
		titleColumn.setSortable(true);
		authorColumn.setSortable(true);
		publisherColumn.setSortable(true);

		// Dann brauchen wir einen Handler, der den Event des Sortierens
		// abfangen kann. Der Handler bekommt die List des DataProviders
		// uebergeben. Den Handler fuegen wir an die Tabelle an.
		ListHandler<Book> sortHandler = new ListHandler<Book>(
				bookDataProvider.getList());
		bookTable.addColumnSortHandler(sortHandler);

		// Um zu Sortieren muss der Handler die Buecher vergleichen.
		// Wir legen einen Comparator an, der uns die Spalte ISBN vergleicht.
		sortHandler.setComparator(isbnColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die isbn
				if (o1.getIsbn() > o2.getIsbn()) {
					return 1;
				}
				if (o1.getIsbn() < o2.getIsbn()) {
					return -1;
				}
				return 0;
			}
		});

		// Dann brauchen wir eine Comparator fuer die Titel-Spalte.
		sortHandler.setComparator(titleColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die Titel der Buecher.
				// Der Datentyp String bietet bereits eine Vergleichsoperation.
				return o1.getTitle().compareTo(o2.getTitle());
			}
		});

		// Zum Schluss wollen wir auch noch anhand der Authoren sortieren.
		sortHandler.setComparator(authorColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die Authoren.
				return o1.getAuthor().compareTo(o2.getAuthor());
			}
		});

		// Wir wollen auch noch anhand des Verlages sortieren.
		sortHandler.setComparator(publisherColumn, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// Hier vergleichen wir die Verlage.
				return o1.getPublisher().compareTo(o2.getPublisher());
			}
		});

	}

	private void updateTable() {
		bookDataProvider.setList(bookList);
	}

	private void saveBooks() {
		bookService.saveBooks(bookList, new AsyncCallback<Void>() {

			@Override
			public void onFailure(Throwable caught) {
				GWT.log(caught.getMessage());
			}

			@Override
			public void onSuccess(Void result) {
				// Da wir nur die Aenderungen uebertragen, brauchen wir
				// hier auch nichts machen
				GWT.log("All changes saved.");
			}
		});
	}

}
